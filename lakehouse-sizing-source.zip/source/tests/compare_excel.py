"""After test_export.js writes /tmp/t_<scenario>.xlsx, recalculate each file in LibreOffice
(for example: soffice --headless --convert-to xlsx --outdir /tmp/out /tmp/t_base.xlsx)
and run this script to compare every recalculated cell with the page's own values."""
import json, sys
from openpyxl import load_workbook
tot = bad = 0
for n in ["base", "uat_base", "dev_svc", "batch_all", "fixed", "big"]:
    d = json.load(open(f"/tmp/t_{n}.json")); wb = load_workbook(f"/tmp/t_{n}.xlsx", data_only=True)
    for key, exp in d["exp"].items():
        s, r, k = key.split("|"); ks = d["keys"][s + "|" + r]
        got = wb[s].cell(int(r), 3 + ks.index(k)).value; tot += 1
        ok = (abs(got - exp) <= 1e-6 * max(1, abs(exp))) if isinstance(exp, (int, float)) and isinstance(got, (int, float)) else got == exp
        if not ok: bad += 1; print(n, key, exp, got)
print("compared", tot, "mismatches", bad)
